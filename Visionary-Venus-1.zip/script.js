// Below is an event handler for the scroll event on the window object. It triggers the function every time the user scrolls.
document.addEventListener('scroll', function() {
  // The line of code below gets the current vertical position of the scroll bar. scrollTop() is a jQuery method that returns the vertical scrollbar position for the first element in the set of matched elements or sets the vertical scrollbar position for every matched element.
  var scrollPosition = window.pageYOffset;

  // This line below changes the background-position property of the .parallax-image class.
  document.querySelector('.parallax-image').style.transform = 'translateY(' + scrollPosition * .6 + 'px)';

  //NOTE: Remember that the * 0.5 value above can be adjusted as desired. The smaller the value, the slower the background image will move relative to the rest of the content, enhancing the parallax effect.
});

// Javascript for the modal



window.onscroll = function() {myFunction()};


//by the way, do transitions not work when you full screen replit? i have one on the lowest text box, but it doesn't appear whenever I open replit to another tab

// okay i think its kind of working? it has the glitchy effect the website said it would, but also i thought the sticky class would help fix that

var topnav = document.getElementById("topnav");
var sticky = topnav.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    topnav.classList.add("sticky")
  } else {
    topnav.classList.remove("sticky");
  }
}

 window.onscroll = function() { myFunction() };

  var navbar = document.getElementById("topnav");
  var sticky = navbar.offsetTop;

  function myFunction() {
    if (window.pageYOffset >= sticky) {
      navbar.classList.add("sticky");
    } else {
      navbar.classList.remove("sticky");
    }
  }