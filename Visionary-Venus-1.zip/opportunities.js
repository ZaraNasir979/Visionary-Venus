// -------------------------------------
class Opportunity {
  // Opportunity represents each program, with properties of the link, name, grade levels, program focus
  constructor(link, name, topic, grades, focus, blurb) {
    this.link = link; // link: string of the link (href)
    this.name = name; // name: string of the program name
    this.topic = topic; // topic: string of s, t, e, or m
    this.grades = grades; // grades: array of grade numbers
    this.focus = focus; // focus: string (coed or fn)
    this.blurb = blurb; // blurb: description of program
  }
}

// Create the different opportunities objects & put them in an array
var blurb_1 = 'PARS is a workshop led by expert clinicians and scientists. PARS incorporates a mix of small-group discussions, demonstrations, and hands-on lab activities to explore current research topics in reproductive health.10-12th graders in the Philadelphia area can apply.';
const op_1 = new Opportunity('https://irm.med.upenn.edu/outreach/outreach-programs/penn-academy-for-reproductive-sciences-pars', 'University of Pennsylvania Academy for Reproductive Sciences', 's', [10, 11, 12], 'fn', blurb_1);

var blurb_2='GSTEM is an NYU summer research program for talented high school students who want to learn in an inclusive, supportive environment. Our program strives to break down barriers and empower those who have been historically underrepresented in STEM—especially girls and other minorities.';
const op_2 = new Opportunity('https://cims.nyu.edu/gstem/', 'NYU GSTEM', 's', [11], 'fn', blurb_2);

var blurb_3='STEMEd for Girls is a FREE series of lively, informative, and engaging virtual workshops that will pave the way for your success as you move through high school, into college, and eventually on to your career. ';
const op_3 = new Opportunity('https://www.aauw.org/resources/programs/stemed-for-girls/', 'AAUW STEMEd For Girls', 's', [9,10,11,12], 'fn', blurb_3);

var blurb_4='Founded in 1984, Science Olympiad is the premier team STEM competition in the nation, providing standards-based challenges to 6,000 teams at 425 tournaments in all 50 states.';
const op_4 = new Opportunity('https://www.soinc.org/', 'International Science Olympiad', 's', [1,2,3,4,5,6,7,8,9,10,11,12], 'coed', blurb_4);

var blurb_5='COSMOS is an intensive four-week summer residential Pre-College Program for high school students who have demonstrated an aptitude for academic and professional careers in science, technology, engineering, and mathematics (STEM) subjects.';
const op_5 = new Opportunity('https://cosmos-ucop.ucdavis.edu/app/main', 'COSMOS UCs', 's', [8,9,10,11], 'coed', blurb_5);

var blurb_6='A Regeneron ISEF-affiliated science fair is a research-based, high school competition that is a member of Society for Science & the Public’s affiliated fair network.';
const op_6 = new Opportunity('https://www.societyforscience.org/isef/', 'ISEF', 's', [9,10,11,12], 'coed', blurb_6);

var blurb_7='The U.S. Department of Energy (DOE) National Science Bowl® is a nationwide academic competition that tests students’ knowledge in all areas of science and mathematics.';
const op_7 = new Opportunity('https://science.osti.gov/wdts/nsb', 'National Science Bowl', 's', [6,7,8,9,10,11,12], 'coed', blurb_7);

var blurb_8='THINK is a science, research, and innovation program for high school students. Rather than requiring students to have completed a research project before applying, THINK caters to students who have done extensive research on the background of a potential research project and are looking for additional guidance in the early stages of their project.';
const op_8 = new Opportunity('https://think.mit.edu/#', 'MIT Think Scholars Program', 's', [9,10,11,12], 'coed', blurb_8);

var blurb_9='Since 1999, we have helped our nations most gifted youth reach their highest potential.We offer programs, resources, scholarships, and opportunities for gifted young learners that are driven by their natural talent and abilities, not by their age, socioeconomic status or location.';
const op_9 = new Opportunity('https://www.davidsongifted.org/', 'Davidson Institute', 'stem', [1,2,3,4,5,6,7,8,9,10,11,12], 'coed', blurb_9);

var blurb_10='Our annual symposium, competition, and year-round digital programming is backed by the Department of Defense (DoD), and administered by the National Science Teaching Association (NSTA). We’re committed to providing the mentoring, scholarship, and career pathways for young minds from everywhere to find success, growth, and connection in STEM.';
const op_10 = new Opportunity('https://jshs.org/', 'Junior Science and Humanities Symposium', 'stem', [9,10,11,12], 'coed', blurb_10);

var blurb_11='Regeneron STS is the nation’s oldest and most prestigious science research competition for high school students. Started in 1942 as the Westinghouse Science Talent Search, Regeneron STS recognizes and empowers our nation’s most promising young scientists who are developing ideas that could solve society’s most urgent challenges.';
const op_11 = new Opportunity('https://www.societyforscience.org/regeneron-sts/','Regeneron Science Talent Search','s', [9,10,11,12], 'coed', blurb_11);

var blurb_12='HOSA is a global student-led organization recognized by the U.S. Department of Education and the Department of Health and Human Services and several federal and state agencies. HOSA’s mission is to empower HOSA-Future Health Professionals to become leaders in the global health community, through education, collaboration, and experience.';
const op_12= new Opportunity('https://hosa.org/','HOSA','s', [6,7,8,9,10,11,12], 'coed', blurb_12);

var blurb_13='The Center for Talented Youth, a nonprofit academic center of Johns Hopkins University, delivers academic excellence and transformational experiences to advanced learners in grades 2-12.';
const op_13= new Opportunity('https://cty.jhu.edu/', 'John Hopkins CTY', 'stem', [2,3,4,5,6,7,8,9,10,11,12], 'coed', blurb_13);

var blurb_14='Kode With Klossy creates learning experiences and opportunities for young women and gender-expansive youth. Kode With Klossy camps are a series of FREE 2-week coding-intensive camps designed for students of traditionally underrepresented genders in the STEAM fields.';
const op_14= new Opportunity('https://www.kodewithklossy.com/', 'Kode With Klossy', 't', [8,9,10,11,12], 'fn', blurb_14);

var blurb_15='Girls Who Code is on a mission to close the gender gap in technology and to change the image of what a programmer looks like and does.';
const op_15= new Opportunity('https://girlswhocode.com/','Girls Who Code', 't', [3,4,5,6,7,8,9,10,11,12], 'fn', blurb_15);

var blurb_16='American Computer Science League (ACSL) organizes computer programming and computer science contests for K-12 schools, organizations and local groups.';
const op_16= new Opportunity('https://www.acsl.org/about','ACSL', 't', [1,2,3,4,5,6,7,8,9,10,11,12], 'coed', blurb_16);

var blurb_17='The MIT Womens Technology Program (WTP) is a rigorous four-week summer academic experience to introduce high school students to engineering through hands-on classes, labs, and team-based projects in the summer after 11th grade.';
const op_17= new Opportunity('https://web.mit.edu/wtp/', 'MIT Womens Technology Program','te', [11], 'fn', blurb_17);  

var blurb_18='CURIE Academy is a one-week residential program for high school girls, specifically rising juniors and seniors, who desire to learn about engineering in the context of an authentic college experience.';
const op_18= new Opportunity('https://sites.coecis.cornell.edu/curieacademy/', 'Cornell CURIE Academy','e',[11, 12], 'fn', blurb_18);

var blurb_19='Combining the excitement of sport with the rigors of science and technology. We call FIRST Robotics Competition the ultimate Sport for the Mind. High-school student participants call it “the hardest fun you’ll ever have.”';
const op_19= new Opportunity('https://www.firstinspires.org/robotics/frc','FIRST Robotics Competition','e', [9,10,11,12], 'coed', blurb_19);  

var blurb_20='MITES (formerly OEOP) provides transformative experiences that bolster confidence, create lifelong community, and build an exciting, challenging foundation in STEM for highly motivated 7th–12th grade students from diverse and underrepresented backgrounds. Catalyzing change in STEM, our goal is to advance equity and access through hands-on programs that are free of cost to participants and their families.';
const op_20= new Opportunity('https://mites.mit.edu/','MIT Introduction to Technology, Engineering and Science','ste', [7,8,9,10,11,12], 'coed', blurb_20);  

var blurb_21= 'At Girls Who Math, we strive to make STEM fun, approachable, and accessible to young women from all walks of life. We offer a variety of free individual tutoring and group classes to help students in pursuit of STEM knowledge.'
const op_21= new Opportunity('https://girlswhomath.net/','Girls Who Math','m', [1,2,3,4,5,6,7,8,9,10,11,12], 'fn', blurb_21); 

var blurb_22='The Math Mentoring Program was created to inspire and encourage all students, especially young women, to continue their study of mathematics and science, and to learn about careers in which mathematics and science play a role. The program links local female professionals from mathematics-related fields with a group of 2 to 3 8th grade girls.'
const op_22= new Opportunity('https://www.womenandmathmentoring.org/','Women and Math Mentoring Program','m', [8], 'fn', blurb_22);

var blurb_23='The Advantage Testing Foundation/Jane Street Math Prize for Girls is the largest math prize for girls in the world. Each fall at MIT, about 250 young female mathematicians compete in our challenging test of mathematical creativity and insight. Our goal is to promote gender equity in the STEM professions and to encourage young women with exceptional potential to become mathematical and scientific leaders.'
const op_23= new Opportunity('https://mathprize.atfoundation.org/apply','Math Prize for Girls','m', [1,2,3,4,5,6,7,8,9,10,11], 'fn', blurb_23);

var blurb_24='The International Mathematical Olympiad (IMO) is the World Championship Mathematics Competition for High School students and is held annually in a different country.'
const op_24= new Opportunity('https://www.imo-official.org/','Math Olympiad','m', [1,2,3,4,5,6,7,8,9,10,11,12], 'coed', blurb_24);

var blurb_25='The MAA’s American Mathematics Competitions (MAA AMC) program leads the nation in strengthening the mathematical capabilities of the next generation of problem-solvers'
const op_25= new Opportunity('https://www.maa.org/math-competitions/about-amc','AMC(8/10/12)','m', [6,7,8,9,10,11,12], 'coed', blurb_25);

var blurb_26='The MATHCOUNTS Foundation is a 501(c)(3) non-profit organization that reaches students in grades 6-8 in all US states and territories with 2 extracurricular math programs. Hundreds of thousands of students participate in our programs or use our resources each year.'
const op_26= new Opportunity('https://www.mathcounts.org/','MATHCOUNTS','m', [6,7,8], 'coed', blurb_26);

var blurb_27='The American Regions Math League (ARML) is a mathematical problem solving competition primarily for U.S. high school students.'
const op_27= new Opportunity('https://www.arml.com/ARML/arml_2019/page/index.php?page_type=public&page=home','ARML','m', [9,10,11,12], 'coed', blurb_27);

var blurb_28='PROMYS is a six-week summer program at Boston University designed to encourage strongly motivated high school students to explore in depth the creative world of mathematics in a supportive community of peers, counselors, research mathematicians, and visiting scientists.'
const op_28= new Opportunity('https://promys.org/','PROMYS','m', [9,10,11,12], 'coed', blurb_28);


// Making the array of Opportunities objects -------------------
const allOpportunities = [op_1, op_2, op_3, op_4, op_5, 
                          op_6, op_7, op_8, op_9, op_10,
                          op_11, op_12, op_13, op_14, op_15,
                          op_16, op_17, op_18, op_19, op_20,
                          op_21, op_22, op_23, op_24, op_25, 
                          op_26, op_27, op_28];

// -------------------
var button = $('.submit');
button.on("click", getOpps);

var sciCB = false;
var techCB = false;
var engCB = false;
var mathCB = false;
var coedCB = false;
var fnCB = false;
var grade = 0;

/* All of the following should happen once user presses submit  (event listener) */
function getOpps(event) {
  event.preventDefault();
  // Get the user inputs from the form and store them in vars
  if (document.getElementById("science") !== null && document.getElementById("science").checked) {
    sciCB = true;
  }
  if (document.getElementById("tech") !== null && document.getElementById("tech").checked) {
    techCB = true;
  }
  if (document.getElementById("eng") !== null && document.getElementById("eng").checked) {
    engCB = true;
  }
  if (document.getElementById("math") !== null && document.getElementById("math").checked) {
    mathCB = true;
  }
  if (document.getElementById("coed") !== null && document.getElementById("coed").checked) {
    coedCB = true;
  }
  if (document.getElementById("fn") !== null && document.getElementById("fn").checked) {
    fnCB = true;
  }
  grade = $('.grade').val();

  console.log(sciCB, techCB, engCB, mathCB, coedCB, fnCB, grade);


  finalArray = makeOppsArray(sciCB, techCB, engCB, mathCB, coedCB, fnCB, grade);
  dispArray(finalArray);
}




// Loop through the array of objects and add the Opportunity objects that fit user criteria to a new array
function makeOppsArray(sciCB, techCB, engCB, mathCB, coedCB, fnCB, grade) {
  var recs = [];
  for (i = 0; i < allOpportunities.length; i++) {
    if(matchesCriteria(allOpportunities[i], sciCB, techCB, engCB, mathCB, coedCB, fnCB, grade) ) {
      recs.push(allOpportunities[i]);
    }    
  }
  // recs = [...new Set(recs)]; // remove duplicates
  return recs;
}

function matchesCriteria(op, sciCB, techCB, engCB, mathCB, coedCB, fnCB, grade) {
  console.log("inside matchesCriteria");
  grade = parseInt(grade);
  if (sciCB && op.topic.includes("s")  && op.grades.includes(grade)
      && ((coedCB && op.focus == "coed") || (fnCB && op.focus == "fn")))    {
    console.log("inside return true");
    return true;
  } 
  else if (techCB && op.topic.includes("t")  && op.grades.includes(grade)
      && ((coedCB && op.focus == "coed") || (fnCB && op.focus == "fn")))    {
    console.log("inside return true");
    return true;
  } 
  else if (engCB && op.topic.includes("e")  && op.grades.includes(grade)
      && ((coedCB && op.focus == "coed") || (fnCB && op.focus == "fn")))    {
    console.log("inside return true");
    return true;
  } 
  else if (mathCB && op.topic.includes("m")  && op.grades.includes(grade)
      && ((coedCB && op.focus == "coed") || (fnCB && op.focus == "fn")))    {
    console.log("inside return true");
    return true;
  } 
  else { return false; }
}



// Display these links on the page
function dispArray(finalArray) {
  for (i = 0; i < finalArray.length; i++) {
    // Create anchor element.
    var a = document.createElement('a'); 
    a.style.color = "black";
                      
    // Create the text node for anchor element.
    var link = document.createTextNode(finalArray[i].name);
                      
    // Append the text node to anchor element.
    a.appendChild(link); 
                      
    // Set the title.
    a.title = "This is Link"; 
                      
    // Set the href property.
    a.href = finalArray[i].link; 
                      
    // Append the anchor element to the body.
    document.getElementById("links").appendChild(a); 
    var space = document.createElement('br');
    document.getElementById("links").appendChild(space);
    var p = document.createElement('p');
    p.innerText = finalArray[i].blurb;
    document.getElementById("links").appendChild(p);
    // document.getElementById("links").appendChild(space);

  }


  console.log(`all the stuff: ${allOpportunities}`);
  console.log(`the final array items:`)
  for (let i = 0; i < finalArray.length; i++) {
    console.log(finalArray[i]);
  }
  
}
