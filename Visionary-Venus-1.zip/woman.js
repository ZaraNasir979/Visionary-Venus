// -------------for WOC feature----------//
var modal = document.getElementById("myModal");
var buttons = document.querySelectorAll(".modal-button");

  // Get the content container inside the modal
  var modalBody = modal.querySelector(".modal-body");

  // Loop through each button and add a click event listener
  buttons.forEach(function (button) {
    button.addEventListener("click", function () {
      // Get the content from the button's data attribute
      var content = button.getAttribute("data-content");
      // Update the content of the modal body
      modalBody.innerHTML = content;
      // Show the modal
      modal.style.display = "block";
    });
  });

  // Close the modal when the close button is clicked
  var closeButton = modal.querySelector(".close");
  closeButton.addEventListener("click", function () {
    modal.style.display = "none";
  });

  // Close the modal when the user clicks outside of it
  window.addEventListener("click", function (event) {
    if (event.target === modal) {
      modal.style.display = "none";
    }
  });


